/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m1hw;

import java.util.Scanner;

/**
 *
 * @author Jaheim Patterson
 */
public class M1HW {

     public static void maths(){
          
        System.out.println("Welcome to the calculator program!"
                    + " 1. Add"
                
                    + " 2. Subtract"
                
                    + " 3. Divide"
                
                    + " 4. Multiply"
                
                    + " 5. Exit");
        
      
         int num1, num2, sum;
         Scanner scan = new Scanner(System.in);
         int skoolGrade = scan.nextInt();
         
         
         
        switch(skoolGrade){
            case 1:
               System.out.println("Enter First Number: ");
               num1 = scan.nextInt();
               
                System.out.println("Enter Second Number: ");
        num2 = scan.nextInt();
         
        sum = num1 + num2;
                System.out.println("Sum of these numbers: "+sum);
                break;
                
                
            case 2:
                
                 System.out.println("Enter First Number: ");
                 num1 = scan.nextInt();
               
                System.out.println("Enter Second Number: ");
                num2 = scan.nextInt();
                
                sum = num1 - num2;
                System.out.println("Minuend of these numbers: "+sum);
                break;
                
                
            case 3:
                
               System.out.println("Enter First Number: ");
               num1 = scan.nextInt();
               
                System.out.println("Enter Second Number: ");
        num2 = scan.nextInt();
         
        sum = num1/num2;
                System.out.println("Quotient of these numbers: "+sum);
                break;
                
                
            case 4:
                
                System.out.println("Enter First Number: ");
                
               num1 = scan.nextInt();
               
                System.out.println("Enter Second Number: ");
        num2 = scan.nextInt();
        
        sum = num1 * num2;
                System.out.println("Product of these numbers: "+sum);
                break;
                 
               
                
            case 5:
                System.out.println("BYE!");
                break;
            default:
        }
     }
    
    public static void main(String[] args) {
        maths();
    }
    
}
