﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MazeLibrary
{
    public class Player
    {
        private string Name { get; set; }
        private string Password { get; set; }
        private string CharacterClass { get; set; }
        private string CharacterRace { get; set; }

    }
}
