﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConUI
{
    public class ForEach
    {
        public static void DisplayValues(List<string> input)
        {
            foreach (string item in input)
            {
                Console.WriteLine(item);
            }
        }

        public int PasswordUpper(string str)
        {
            int upperCase = 0;

            foreach (char ch in str)
            {
                if (char.IsUpper(ch))
                {
                    upperCase++;
                }
            }

            return upperCase;
        }

        public int PasswordLower(string str)
        {
            int lowerCase = 0;

            foreach (char ch in str)
            {
                if (char.IsLower(ch))
                {
                    lowerCase++;
                }
            }

            return lowerCase;
        }
    }
}