﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConUI
{
    public static class MazeMovement
    {
        public static void MoveNorth(ref int index)
        {
            if (index < 4)
            {
                index++;
            }
        }

        public static void MoveSouth(ref int index)
        {
            if (index > 0)
            {
                index--;
            }
        }
    }
}

